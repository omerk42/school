words = ["Mohammed","Essam","Essam","Essam"];

count =0;
for i = 1:4
    if (words(i) == "Essam")
      count = count +1;  
    end
end

disp(count);

%Essam Anwar  392024443%